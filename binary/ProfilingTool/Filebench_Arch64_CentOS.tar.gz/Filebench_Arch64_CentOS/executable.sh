#!/usr/bin/env bash
#Make workload scripts executable

chmod 777 Filebench_Workloads/*
