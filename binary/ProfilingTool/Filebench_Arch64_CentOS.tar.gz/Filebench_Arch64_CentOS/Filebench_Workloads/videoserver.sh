#!/usr/bin/env bash

#Workload_17

sudo sed -i 's/set $filesize=10g/set $filesize=10m/' /opt/artist/filebench/share/filebench/workloads/videoserver.f;
sudo /opt/artist/filebench/bin/filebench -f  /opt/artist/filebench/share/filebench/workloads/videoserver.f

