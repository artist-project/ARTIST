#!/usr/bin/env bash

#Workload_19


sudo /opt/artist/filebench/bin/filebench -f  /opt/artist/filebench/share/filebench/workloads/webserver.f

