#!/usr/bin/env bash

#Workload_3


sudo /opt/artist/filebench/bin/filebench -f /opt/artist/filebench/share/filebench/workloads/fileserver.f

