#!/usr/bin/env bash

#Workload_16


sudo /opt/artist/filebench/bin/filebench -f  /opt/artist/filebench/share/filebench/workloads/varmail.f

