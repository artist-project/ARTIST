#!/usr/bin/env bash

#Workload_8
sudo sed -i 's/,useism//' /opt/artist/filebench/share/filebench/workloads/oltp.f;
sudo /opt/artist/filebench/bin/filebench -f  /opt/artist/filebench/share/filebench/workloads/oltp.f

