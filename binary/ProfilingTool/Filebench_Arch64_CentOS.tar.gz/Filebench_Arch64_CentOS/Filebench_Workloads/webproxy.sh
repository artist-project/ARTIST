#!/usr/bin/env bash

#Workload_18


sudo /opt/artist/filebench/bin/filebench -f  /opt/artist/filebench/share/filebench/workloads/webproxy.f

