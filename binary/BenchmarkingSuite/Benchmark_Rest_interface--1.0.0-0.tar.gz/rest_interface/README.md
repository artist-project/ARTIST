1) Install Flask Server
http://flask.pocoo.org/docs/0.10/installation/

2) Start the server running the file "app.py"

3) Navigate via browser to http://ip_address:port/benchmarking/ui/ 

