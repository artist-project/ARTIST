namespace DBML_Model.DAL
{
  	public class ServiceProviderRepository : GenericRepository<ServiceProvider>
  	{
  	}
}
