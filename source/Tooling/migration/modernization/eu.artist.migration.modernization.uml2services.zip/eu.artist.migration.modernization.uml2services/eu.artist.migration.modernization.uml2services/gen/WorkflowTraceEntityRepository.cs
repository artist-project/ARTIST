namespace DBML_Model.DAL
{
  	public class WorkflowTraceEntityRepository : GenericRepository<WorkflowTraceEntity>
  	{
  	}
}
