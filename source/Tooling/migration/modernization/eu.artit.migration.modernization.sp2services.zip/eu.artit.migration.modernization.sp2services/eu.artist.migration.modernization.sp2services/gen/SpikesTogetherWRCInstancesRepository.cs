namespace SP_Model.DAL
{
  	public class SpikesTogetherWRCInstancesRepository : GenericRepository<SpikesTogetherWRCInstances>
  	{
  	}
}
