namespace SP_Model.DAL
{
  	public class SpikesTogetherWRCDesignsRepository : GenericRepository<SpikesTogetherWRCDesigns>
  	{
  	}
}
