namespace SP_Model.DAL
{
  	public class SpikesTogetherPendingWorkflowNotificationsRepository : GenericRepository<SpikesTogetherPendingWorkflowNotifications>
  	{
  	}
}
