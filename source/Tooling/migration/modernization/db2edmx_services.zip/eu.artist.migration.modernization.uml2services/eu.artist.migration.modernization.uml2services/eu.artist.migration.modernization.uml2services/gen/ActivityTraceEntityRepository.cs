namespace DBML_Model.DAL
{
  	public class ActivityTraceEntityRepository : GenericRepository<ActivityTraceEntity>
  	{
  	}
}
