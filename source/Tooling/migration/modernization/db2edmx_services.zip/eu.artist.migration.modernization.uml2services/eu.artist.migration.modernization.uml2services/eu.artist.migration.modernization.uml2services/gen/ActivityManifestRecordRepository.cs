namespace DBML_Model.DAL
{
  	public class ActivityManifestRecordRepository : GenericRepository<ActivityManifestRecord>
  	{
  	}
}
