namespace DBML_Model.DAL
{
  	public class WorkflowQueueRepository : GenericRepository<WorkflowQueue>
  	{
  	}
}
