namespace DBML_Model.DAL
{
  	public class TaskTraceEntityRepository : GenericRepository<TaskTraceEntity>
  	{
  	}
}
