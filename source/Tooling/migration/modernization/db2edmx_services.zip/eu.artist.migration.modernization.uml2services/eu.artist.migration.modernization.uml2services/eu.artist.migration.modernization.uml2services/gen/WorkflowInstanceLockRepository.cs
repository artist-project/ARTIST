namespace DBML_Model.DAL
{
  	public class WorkflowInstanceLockRepository : GenericRepository<WorkflowInstanceLock>
  	{
  	}
}
