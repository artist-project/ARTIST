UML to EDMX Model generator, Version 1.0.0

=========================================

ABOUT
-----
This component is the second part of a complete migration chain, i.e. forward engineer 
the platform independent Database model (obtained by the component described in) into 
a platform specific Entity Framework model . This model can then be used as input for the 
final phase in which the actual code can be generated. This model mainly focuses on 
C#/.NET applications. In addition, the Database model can also be used to generate C# 
source code describing so-called service classes.


=========================================================================================

INCLUDED FUNCTIONALITIES
------------------------

=========================================================================================

KNOWN ISSUES
------------	

=========================================================================================

EXPECTED FUNCTIONALITIES
------------------------

=========================================================================================

INSTALLATION AND USER MANUAL
----------------------------
In the deliverable 'D9.3 Migration Rules Formalized As Generic Model Transformations' of 
the ARTIST project website (artist-project.eu). Download and installation instructions as
well as the manual can be found in section 3.3.2