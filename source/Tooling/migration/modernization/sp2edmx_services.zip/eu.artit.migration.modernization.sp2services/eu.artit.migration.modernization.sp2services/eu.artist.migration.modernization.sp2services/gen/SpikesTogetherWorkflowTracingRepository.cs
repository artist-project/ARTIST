namespace SP_Model.DAL
{
  	public class SpikesTogetherWorkflowTracingRepository : GenericRepository<SpikesTogetherWorkflowTracing>
  	{
  	}
}
