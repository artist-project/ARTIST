namespace SP_Model.DAL
{
  	public class SpikesTogetherWRCDeploymentsRepository : GenericRepository<SpikesTogetherWRCDeployments>
  	{
  	}
}
