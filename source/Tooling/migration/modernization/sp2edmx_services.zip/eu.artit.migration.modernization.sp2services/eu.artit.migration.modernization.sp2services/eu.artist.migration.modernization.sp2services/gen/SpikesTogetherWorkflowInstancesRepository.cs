namespace SP_Model.DAL
{
  	public class SpikesTogetherWorkflowInstancesRepository : GenericRepository<SpikesTogetherWorkflowInstances>
  	{
  	}
}
