SharePoint model to EDMX model generator, Version 1.0.0

=======================================================

ABOUT
-----
In the context of migrating SharePoint list definitions towards a relational database 
schema, this component is the second part of a complete migration chain, i.e. forward 
engineer the platform independent Database model (obtained by the component described in) 
into a platform specific Entity Framework model . This model can then be used to either 
generate the database schema (and consequently also the database) as well as generate 
the data access layer for performing CRUD operations on this database.

=========================================================================================

INCLUDED FUNCTIONALITIES
------------------------

=========================================================================================

KNOWN ISSUES
------------	

=========================================================================================

EXPECTED FUNCTIONALITIES
------------------------

=========================================================================================

INSTALLATION AND USER MANUAL
----------------------------
In the deliverable 'D9.3 Migration Rules Formalized As Generic Model Transformations' of 
the ARTIST project website (artist-project.eu). Download and installation instructions as
well as the manual can be found in section 3.3.3