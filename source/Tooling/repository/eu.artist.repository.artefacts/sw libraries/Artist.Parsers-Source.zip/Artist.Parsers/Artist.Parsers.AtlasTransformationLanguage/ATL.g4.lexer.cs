﻿namespace Artist.Parsers.AtlasTransformationLanguage
{
    partial class ATLLexer
    {
    }
}
